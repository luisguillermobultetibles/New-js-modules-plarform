// Proveedor base abstracto
class ModuleProvider {
    constructor(name, config) {
        this.name = name;
        this.config = config;
        this.priority = config.priority || 1;
        this.enabled = config.enabled !== false;
    }

    async init() {
        throw new Error('Método init() debe ser implementado');
    }

    async hasModule(moduleId) {
        throw new Error('Método hasModule() debe ser implementado');
    }

    async loadModule(moduleId) {
        throw new Error('Método loadModule() debe ser implementado');
    }

    async storeModule(moduleId, code, metadata) {
        throw new Error('Método storeModule() debe ser implementado');
    }

    getHealth() {
        return {
            provider: this.name,
            enabled: this.enabled,
            healthy: true,
            latency: 0
        };
    }
}
 
