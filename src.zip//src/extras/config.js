// config.js - Configuración centralizada
export const MODULE_SYSTEM_CONFIG = {
    // Entorno
    environment: process.env.NODE_ENV || 'development',
    
    // Estrategia
    strategy: 'hybrid', // 'local-first', 'remote-first', 'parallel'
    cacheEnabled: true,
    autoSync: true,
    
    // Proveedores
    providers: {
        local: {
            enabled: true,
            priority: 1,
            maxSize: 5 * 1024 * 1024, // 5MB
            cleanupThreshold: 0.8 // 80%
        },
        
        webrtc: {
            enabled: true,
            priority: 2,
            signalingServers: [
                'wss://signaling1.libraries.dev',
                'wss://signaling2.libraries.dev',
                'wss://signaling3.libraries.dev'
            ],
            iceServers: [
                { urls: 'stun:stun.l.google.com:19302' },
                { urls: 'stun:global.stun.twilio.com:3478' }
            ],
            channel: 'module-distribution'
        },
        
        http: {
            enabled: true,
            priority: 3,
            endpoints: [
                'https://api.modules.dev/v1',
                'https://cdn.modules.pub/v1',
                'https://backup.modules.net/v1'
            ],
            timeout: 10000,
            retries: 3
        },
        
        ipfs: {
            enabled: false, // Opcional para futuro
            priority: 4,
            gateway: 'https://ipfs.io/ipfs/',
            bootstrap: [
                '/dns4/ipfs1.modules.dev/tcp/4001/ws/p2p/QmPeer1',
                '/dns4/ipfs2.modules.dev/tcp/4001/ws/p2p/QmPeer2'
            ]
        }
    },
    
    // Registro de módulos
    registry: {
        endpoints: [
            'https://registry.modules.dev',
            'https://backup.registry.modules.dev'
        ],
        publish: true,
        verify: true
    },
    
    // Seguridad
    security: {
        verifySignatures: true,
        allowedOrigins: ['https://modules.dev', 'https://cdn.modules.pub'],
        cors: true
    },
    
    // Desarrollo
    development: {
        debug: true,
        logLevel: 'info', // 'error', 'warn', 'info', 'debug'
        performance: true
    }
};

// Configuración específica por entorno
export const ENV_CONFIGS = {
    development: {
        debug: true,
        logLevel: 'debug',
        providers: {
            http: {
                endpoints: ['http://localhost:3000/v1']
            }
        }
    },
    
    production: {
        debug: false,
        logLevel: 'warn',
        autoSync: false
    }
};
