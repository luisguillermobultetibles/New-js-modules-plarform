// dev-tools.js - Herramientas para desarrollo
class ModuleDevTools {
    constructor(moduleSystem) {
        this.system = moduleSystem;
        this.panel = null;
        this.init();
    }

    init() {
        // Crear panel de desarrollo si no existe
        if (!document.getElementById('module-dev-panel')) {
            this.createDevPanel();
        }
        
        // Registrar comandos de consola
        this.registerConsoleCommands();
    }

    createDevPanel() {
        const panel = document.createElement('div');
        panel.id = 'module-dev-panel';
        panel.style.cssText = `
            position: fixed;
            top: 10px;
            right: 10px;
            background: #1a1a1a;
            color: white;
            padding: 15px;
            border-radius: 8px;
            font-family: 'Courier New', monospace;
            font-size: 12px;
            z-index: 10000;
            max-width: 400px;
            max-height: 500px;
            overflow: auto;
            box-shadow: 0 4px 12px rgba(0,0,0,0.3);
            border: 1px solid #333;
        `;

        panel.innerHTML = this.getPanelHTML();
        document.body.appendChild(panel);
        this.panel = panel;

        // Hacer el panel arrastrable
        this.makeDraggable(panel);
    }

    getPanelHTML() {
        const status = this.system.getNetworkStatus();
        return `
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
                <strong>🔧 Module System DevTools</strong>
                <button onclick="this.parentElement.parentElement.remove()" style="background: none; border: none; color: white; cursor: pointer;">×</button>
            </div>
            
            <div style="margin-bottom: 10px;">
                <div>📦 Modules: ${this.system.moduleRegistry.size}</div>
                <div>💾 Cache: ${this.system.cache.size} items</div>
                <div>🌐 Providers: ${status.providers ? Object.keys(status.providers).length : 0}</div>
            </div>

            <div style="margin-bottom: 10px;">
                <button onclick="devTools.runDiagnostics()" style="background: #007acc; border: none; color: white; padding: 5px 10px; border-radius: 4px; cursor: pointer; margin-right: 5px;">🩺 Diagnose</button>
                <button onclick="devTools.clearCache()" style="background: #d13438; border: none; color: white; padding: 5px 10px; border-radius: 4px; cursor: pointer;">🗑️ Clear Cache</button>
            </div>

            <div style="margin-bottom: 10px;">
                <input type="text" id="module-test-input" placeholder="module-name" style="width: 120px; padding: 4px; border: 1px solid #555; background: #2a2a2a; color: white; border-radius: 4px; margin-right: 5px;">
                <button onclick="devTools.testLoad()" style="background: #107c10; border: none; color: white; padding: 4px 8px; border-radius: 4px; cursor: pointer;">🧪 Test Load</button>
            </div>

            <div id="dev-tools-log" style="font-size: 11px; max-height: 200px; overflow-y: auto; border-top: 1px solid #333; padding-top: 10px;"></div>
        `;
    }

    registerConsoleCommands() {
        window.$modules = {
            system: this.system,
            list: () => this.system.listInstalledModules(),
            load: (name) => this.system.import(name),
            cache: () => this.system.cache,
            stats: () => this.system.getNetworkStatus(),
            diagnose: () => this.runDiagnostics(),
            publish: (name, code) => this.system.publish(name, code),
            clear: () => this.system.clearCache()
        };

        console.log(`
🎉 Module System DevTools Loaded!

Available commands:
  $modules.list()      - List installed modules
  $modules.load(name)  - Load a module
  $modules.cache()     - Show cache
  $modules.stats()     - System statistics
  $modules.diagnose()  - Run diagnostics
  $modules.publish()   - Publish a module
  $modules.clear()     - Clear cache

Use the dev panel or these commands to debug!
        `);
    }

    async runDiagnostics() {
        this.log('🩺 Running diagnostics...');
        
        const diagnostics = {
            timestamp: new Date().toISOString(),
            environment: this.detectEnvironment(),
            storage: this.testStorage(),
            providers: await this.testProviders(),
            modules: await this.testModules(),
            performance: this.testPerformance()
        };

        this.log('✅ Diagnostics complete');
        console.table(diagnostics);
        return diagnostics;
    }

    detectEnvironment() {
        return {
            userAgent: navigator.userAgent,
            online: navigator.onLine,
            https: location.protocol === 'https:',
            localStorage: !!window.localStorage,
            webrtc: !!window.RTCPeerConnection,
            workers: !!window.Worker
        };
    }

    testStorage() {
        try {
            const testData = { test: 'data', timestamp: Date.now() };
            localStorage.setItem('module_test', JSON.stringify(testData));
            const retrieved = JSON.parse(localStorage.getItem('module_test'));
            localStorage.removeItem('module_test');
            
            return {
                available: true,
                working: retrieved.test === 'data',
                quota: this.estimateQuota()
            };
        } catch (error) {
            return { available: false, error: error.message };
        }
    }

    async testProviders() {
        const results = {};
        const providers = this.system.providers;
        
        for (const [name, provider] of providers) {
            try {
                const health = await provider.getHealth();
                results[name] = { ...health, status: 'healthy' };
            } catch (error) {
                results[name] = { status: 'error', error: error.message };
            }
        }
        
        return results;
    }

    async testModules() {
        const modules = this.system.listInstalledModules();
        const results = {};
        
        for (const module of modules.slice(0, 3)) { // Test primeros 3
            try {
                const health = await this.system.healthCheck(module.name);
                results[module.name] = health;
            } catch (error) {
                results[module.name] = { healthy: false, error: error.message };
            }
        }
        
        return results;
    }

    testPerformance() {
        const start = performance.now();
        
        // Test de operaciones básicas
        for (let i = 0; i < 1000; i++) {
            this.system.cache.set(`test_${i}`, { data: i });
        }
        
        const end = performance.now();
        return { operationTime: end - start };
    }

    clearCache() {
        this.system.clearCache();
        this.log('🗑️ Cache cleared');
    }

    async testLoad() {
        const input = document.getElementById('module-test-input');
        const moduleName = input.value.trim();
        
        if (!moduleName) {
            this.log('❌ Please enter a module name', 'error');
            return;
        }

        this.log(`🧪 Testing load: ${moduleName}`);
        
        try {
            const start = performance.now();
            const module = await this.system.import(moduleName);
            const end = performance.now();
            
            this.log(`✅ Loaded in ${(end - start).toFixed(2)}ms`, 'success');
            console.log(`Module ${moduleName}:`, module);
        } catch (error) {
            this.log(`❌ Failed to load: ${error.message}`, 'error');
        }
    }

    log(message, type = 'info') {
        const logElement = this.panel.querySelector('#dev-tools-log');
        const entry = document.createElement('div');
        
        const colors = {
            info: '#cccccc',
            success: '#4caf50',
            error: '#f44336',
            warning: '#ff9800'
        };
        
        entry.style.color = colors[type] || colors.info;
        entry.textContent = `[${new Date().toLocaleTimeString()}] ${message}`;
        
        logElement.appendChild(entry);
        logElement.scrollTop = logElement.scrollHeight;
    }

    makeDraggable(element) {
        let pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
        
        element.onmousedown = dragMouseDown;

        function dragMouseDown(e) {
            e = e || window.event;
            e.preventDefault();
            pos3 = e.clientX;
            pos4 = e.clientY;
            document.onmouseup = closeDragElement;
            document.onmousemove = elementDrag;
        }

        function elementDrag(e) {
            e = e || window.event;
            e.preventDefault();
            pos1 = pos3 - e.clientX;
            pos2 = pos4 - e.clientY;
            pos3 = e.clientX;
            pos4 = e.clientY;
            element.style.top = (element.offsetTop - pos2) + "px";
            element.style.left = (element.offsetLeft - pos1) + "px";
        }

        function closeDragElement() {
            document.onmouseup = null;
            document.onmousemove = null;
        }
    }
}

// Inicialización automática en desarrollo
if (process.env.NODE_ENV === 'development') {
    window.addEventListener('load', () => {
        setTimeout(() => {
            window.devTools = new ModuleDevTools(universalModuleSystem);
        }, 1000);
    });
}
