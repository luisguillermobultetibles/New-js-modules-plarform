// Proveedor HTTP CDN
class HTTPProvider extends ModuleProvider {
    async init() {
        this.endpoints = this.config.endpoints || [];
        this._log(`HTTP provider with ${this.endpoints.length} endpoints`);
        return true;
    }

    async hasModule(moduleId) {
        // Verificar si el endpoint responde
        try {
            const response = await fetch(`${this.endpoints[0]}/${moduleId.name}/meta`);
            return response.ok;
        } catch {
            return false;
        }
    }

    async loadModule(moduleId) {
        for (const endpoint of this.endpoints) {
            try {
                const response = await fetch(`${endpoint}/${moduleId.name}`);
                if (!response.ok) continue;
                
                const data = await response.json();
                return {
                    code: data.code,
                    metadata: {
                        version: data.version,
                        source: endpoint,
                        signature: data.signature,
                        dependencies: data.dependencies
                    }
                };
            } catch (error) {
                console.warn(`Endpoint failed: ${endpoint}`, error);
            }
        }
        
        throw new Error(`Module not found in any HTTP endpoint: ${moduleId.name}`);
    }

    async storeModule(moduleId, code, metadata) {
        // Los proveedores HTTP generalmente son de solo lectura
        throw new Error('HTTP providers are read-only');
    }
}
