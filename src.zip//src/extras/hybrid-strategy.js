// Estrategia de carga híbrida
class HybridLoadStrategy {
    constructor(providers, config) {
        this.providers = providers;
        this.config = config;
    }

    async loadModule(resolvedId, options = {}) {
        const strategies = {
            'local-first': this._localFirst.bind(this),
            'remote-first': this._remoteFirst.bind(this),
            'parallel': this._parallel.bind(this),
            'hybrid': this._hybrid.bind(this)
        };

        const strategy = strategies[this.config.strategy] || strategies.hybrid;
        return strategy(resolvedId, options);
    }

    async _localFirst(resolvedId, options) {
        // 1. Intentar proveedores locales
        for (const provider of this._getProvidersByType('local')) {
            try {
                if (await provider.hasModule(resolvedId)) {
                    return await provider.loadModule(resolvedId);
                }
            } catch (error) {
                console.warn(`Local provider ${provider.name} failed:`, error);
            }
        }

        // 2. Fallback a remotos
        for (const provider of this._getProvidersByType('remote')) {
            try {
                const module = await provider.loadModule(resolvedId);
                
                // Cachear localmente si es posible
                await this._cacheLocally(resolvedId, module);
                return module;
                
            } catch (error) {
                console.warn(`Remote provider ${provider.name} failed:`, error);
            }
        }

        throw new Error(`Module not found: ${resolvedId.id}`);
    }

    async _hybrid(resolvedId, options) {
        // Carga en paralelo de múltiples fuentes
        const providers = this._getPrioritizedProviders();
        const promises = [];
        
        for (const provider of providers) {
            if (await provider.hasModule(resolvedId)) {
                promises.push(
                    provider.loadModule(resolvedId)
                        .then(module => ({ provider: provider.name, module, source: 'cache' }))
                        .catch(error => ({ provider: provider.name, error }))
                );
            }
        }

        const results = await Promise.allSettled(promises);
        
        // Encontrar el primer resultado exitoso
        for (const result of results) {
            if (result.status === 'fulfilled' && result.value.module) {
                const { provider, module } = result.value;
                
                // Replicar en otros proveedores (background)
                this._replicateModule(resolvedId, module);
                
                return module;
            }
        }

        throw new Error(`Module not available from any provider: ${resolvedId.id}`);
    }

    _getPrioritizedProviders() {
        return Array.from(this.providers.values())
            .filter(p => p.enabled)
            .sort((a, b) => a.priority - b.priority);
    }

    _getProvidersByType(type) {
        return this._getPrioritizedProviders()
            .filter(provider => {
                if (type === 'local') return provider instanceof LocalStorageProvider;
                if (type === 'remote') return !(provider instanceof LocalStorageProvider);
                return true;
            });
    }

    async _cacheLocally(moduleId, moduleData) {
        const localProvider = this._getProvidersByType('local')[0];
        if (localProvider) {
            try {
                await localProvider.storeModule(moduleId, moduleData.code, {
                    ...moduleData.metadata,
                    cachedFrom: moduleData.metadata.source
                });
            } catch (error) {
                console.warn('Failed to cache module locally:', error);
            }
        }
    }

    async _replicateModule(moduleId, moduleData) {
        // Replicar en otros proveedores disponibles
        const providers = this._getPrioritizedProviders()
            .filter(p => p.name !== moduleData.metadata.source);
        
        for (const provider of providers) {
            if (provider.storeModule) {
                provider.storeModule(moduleId, moduleData.code, moduleData.metadata)
                    .catch(error => console.warn(`Replication failed for ${provider.name}:`, error));
            }
        }
    }
}
