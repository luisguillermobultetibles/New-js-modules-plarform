// init.js - Inicialización de la aplicación
import { MODULE_SYSTEM_CONFIG, ENV_CONFIGS } from './config.js';

class AppInitializer {
    constructor() {
        this.config = this.getConfig();
        this.moduleSystem = null;
        this.isInitialized = false;
    }

    getConfig() {
        const env = process.env.NODE_ENV || 'development';
        const envConfig = ENV_CONFIGS[env] || {};
        
        return {
            ...MODULE_SYSTEM_CONFIG,
            ...envConfig,
            environment: env
        };
    }

    async initialize() {
        if (this.isInitialized) return this.moduleSystem;

        try {
            console.log('🚀 Initializing Universal Module System...');
            
            // 1. Cargar el sistema de módulos
            this.moduleSystem = new UniversalModuleSystem(this.config);
            
            // 2. Esperar inicialización completa
            await this.moduleSystem.ready;
            
            // 3. Precargar módulos esenciales
            await this.preloadEssentialModules();
            
            // 4. Inicializar herramientas de desarrollo
            if (this.config.development.debug) {
                await this.initializeDevTools();
            }
            
            // 5. Configurar event listeners globales
            this.setupGlobalHandlers();
            
            this.isInitialized = true;
            console.log('✅ Module system initialized successfully');
            
            return this.moduleSystem;
            
        } catch (error) {
            console.error('❌ Failed to initialize module system:', error);
            throw error;
        }
    }

    async preloadEssentialModules() {
        const essentialModules = [
            'local:math-utils',
            'local:dom-helpers',
            'local:storage-manager'
        ];

        console.log('📦 Preloading essential modules...');
        
        const results = await Promise.allSettled(
            essentialModules.map(module => this.moduleSystem.import(module))
        );

        results.forEach((result, index) => {
            if (result.status === 'fulfilled') {
                console.log(`✅ Loaded: ${essentialModules[index]}`);
            } else {
                console.warn(`⚠️ Failed to load: ${essentialModules[index]}`, result.reason);
            }
        });
    }

    async initializeDevTools() {
        // Cargar herramientas de desarrollo de forma condicional
        if (typeof window !== 'undefined') {
            const { default: DevTools } = await import('./dev-tools.js');
            window.devTools = new DevTools(this.moduleSystem);
        }
    }

    setupGlobalHandlers() {
        // Manejar errores de módulos
        window.addEventListener('unhandledrejection', (event) => {
            if (event.reason && event.reason.message.includes('module')) {
                console.error('Module loading error:', event.reason);
                event.preventDefault();
            }
        });

        // Sincronizar cuando vuelve la conexión
        window.addEventListener('online', () => {
            console.log('🌐 Connection restored - syncing modules...');
            this.syncModules();
        });
    }

    async syncModules() {
        if (!this.config.autoSync) return;
        
        try {
            const modules = this.moduleSystem.listInstalledModules();
            const syncPromises = modules.map(module => 
                this.moduleSystem.syncModule(module.name)
            );
            
            await Promise.allSettled(syncPromises);
            console.log('🔄 Module sync completed');
        } catch (error) {
            console.warn('Module sync failed:', error);
        }
    }

    // Método de conveniencia para aplicaciones
    async loadAppModule(moduleName) {
        if (!this.isInitialized) {
            await this.initialize();
        }
        
        return this.moduleSystem.import(moduleName);
    }
}

// Exportar singleton
const appInitializer = new AppInitializer();

// Inicialización automática para aplicaciones web
if (typeof window !== 'undefined') {
    window.AppModules = appInitializer;
}

export default appInitializer;
