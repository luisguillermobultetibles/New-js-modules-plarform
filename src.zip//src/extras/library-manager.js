// Gestor avanzado para administrar librerías
class LibreriaManager {
    constructor() {
        this.libreriasDisponibles = {
            'lodash-mini': `
                module.exports = {
                    debounce: (func, wait) => {
                        let timeout;
                        return function executedFunction(...args) {
                            const later = () => {
                                clearTimeout(timeout);
                                func(...args);
                            };
                            clearTimeout(timeout);
                            timeout = setTimeout(later, wait);
                        };
                    },
                    
                    throttle: (func, limit) => {
                        let inThrottle;
                        return function(...args) {
                            if (!inThrottle) {
                                func.apply(this, args);
                                inThrottle = true;
                                setTimeout(() => inThrottle = false, limit);
                            }
                        };
                    },
                    
                    clone: (obj) => JSON.parse(JSON.stringify(obj)),
                    
                    isEmpty: (obj) => {
                        if (obj == null) return true;
                        if (Array.isArray(obj) || typeof obj === 'string') 
                            return obj.length === 0;
                        return Object.keys(obj).length === 0;
                    }
                };
            `,

            'validator': `
                module.exports = {
                    isEmail: (email) => {
                        return /^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/.test(email);
                    },
                    
                    isURL: (url) => {
                        try {
                            new URL(url);
                            return true;
                        } catch {
                            return false;
                        }
                    },
                    
                    isNumber: (n) => !isNaN(parseFloat(n)) && isFinite(n),
                    
                    isEmpty: (str) => !str || str.trim().length === 0,
                    
                    isStrongPassword: (password) => {
                        return password.length >= 8 && 
                               /[A-Z]/.test(password) && 
                               /[a-z]/.test(password) && 
                               /[0-9]/.test(password);
                    }
                };
            `
        };
    }

    // Instalar una librería
    instalar(nombre) {
        if (this.libreriasDisponibles[nombre]) {
            ModuleSystem.saveToLocalStorage(nombre, this.libreriasDisponibles[nombre]);
            return true;
        }
        return false;
    }

    // Instalar todas las librerías disponibles
    instalarTodas() {
        Object.keys(this.libreriasDisponibles).forEach(nombre => {
            this.instalar(nombre);
        });
    }

    // Listar librerías instaladas
    listarInstaladas() {
        return ModuleSystem.listModules().filter(mod => 
            Object.keys(this.libreriasDisponibles).includes(mod)
        );
    }

    // Desinstalar librería
    desinstalar(nombre) {
        ModuleSystem.removeModule(nombre);
    }
}

// Uso del gestor
const gestorLibrerias = new LibreriaManager();

// Instalar librerías
gestorLibrerias.instalarTodas();
