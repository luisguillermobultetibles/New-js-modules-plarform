// Proveedor LocalStorage
class LocalStorageProvider extends ModuleProvider {
    async init() {
        this._log('LocalStorage provider ready');
        return true;
    }

    async hasModule(moduleId) {
        return localStorage.getItem(`module_${moduleId.name}`) !== null;
    }

    async loadModule(moduleId) {
        const stored = localStorage.getItem(`module_${moduleId.name}`);
        if (!stored) throw new Error('Module not found in localStorage');
        
        const data = JSON.parse(stored);
        return {
            code: data.code,
            metadata: {
                version: data.version,
                source: 'local-storage',
                timestamp: data.timestamp
            }
        };
    }

    async storeModule(moduleId, code, metadata) {
        const moduleData = {
            code,
            version: metadata.version || '1.0.0',
            timestamp: Date.now(),
            source: 'local-storage',
            ...metadata
        };
        
        localStorage.setItem(`module_${moduleId.name}`, JSON.stringify(moduleData));
        return true;
    }
}

 
