// Ejemplo 1: Módulo de utilidades compartido
// math-utils.js (publicado en la red)
export const MathUtils = {
    // Operaciones básicas
    sum: (a, b) => a + b,
    multiply: (a, b) => a * b,
    
    // Estadísticas
    average: (arr) => arr.reduce((a, b) => a + b, 0) / arr.length,
    standardDeviation: (arr) => {
        const avg = MathUtils.average(arr);
        const squareDiffs = arr.map(value => Math.pow(value - avg, 2));
        return Math.sqrt(MathUtils.average(squareDiffs));
    },
    
    // Finanzas
    compoundInterest: (principal, rate, time) => 
        principal * Math.pow(1 + rate, time),
    
    // Geometría
    circleArea: (radius) => Math.PI * Math.pow(radius, 2),
    distance: (x1, y1, x2, y2) => Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2))
};

export const Constants = {
    PI: Math.PI,
    E: Math.E,
    GOLDEN_RATIO: 1.61803398875
};

export default MathUtils;
