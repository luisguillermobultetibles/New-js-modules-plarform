// Helper functions para desarrollo con el sistema de módulos
class ModuleHelper {
    static async diagnose() {
        const report = {
            timestamp: new Date().toISOString(),
            system: 'ModuleSystem Diagnostic Report',
            results: {}
        };

        // 1. Verificar localStorage
        report.results.localStorage = ModuleHelper._checkLocalStorage();
        
        // 2. Verificar módulos instalados
        report.results.installedModules = moduleSystem.listInstalledModules();
        
        // 3. Verificar salud de módulos
        report.results.healthChecks = await ModuleHelper._performHealthChecks();
        
        // 4. Uso de almacenamiento
        report.results.storageUsage = moduleSystem.getStorageUsage();
        
        // 5. Información del navegador
        report.results.environment = ModuleHelper._getEnvironmentInfo();
        
        return report;
    }

    static _checkLocalStorage() {
        try {
            const testKey = 'module_system_test';
            localStorage.setItem(testKey, 'test');
            const value = localStorage.getItem(testKey);
            localStorage.removeItem(testKey);
            
            return {
                available: true,
                writable: value === 'test',
                quota: ModuleHelper._estimateQuota()
            };
        } catch (error) {
            return {
                available: false,
                error: error.message
            };
        }
    }

    static async _performHealthChecks() {
        const modules = moduleSystem.listInstalledModules();
        const checks = {};
        
        for (const module of modules) {
            if (!module.corrupted) {
                checks[module.name] = await moduleSystem.healthCheck(module.name);
            }
        }
        
        return checks;
    }

    static _getEnvironmentInfo() {
        return {
            userAgent: navigator.userAgent,
            platform: navigator.platform,
            cookiesEnabled: navigator.cookieEnabled,
            language: navigator.language,
            online: navigator.onLine,
            jsEngine: {
                features: {
                    modules: typeof Module !== 'undefined',
                    dynamicImport: typeof import !== 'undefined',
                    promises: typeof Promise !== 'undefined',
                    asyncAwait: (async () => {}).constructor === AsyncFunction
                }
            }
        };
    }

    static _estimateQuota() {
        try {
            // Estimación básica
            return '5MB (estimado)';
        } catch (error) {
            return 'Unknown';
        }
    }

    // Crear módulo de prueba
    static createTestModule(name = 'test-module') {
        const testCode = `
            module.exports = {
                version: '1.0.0',
                timestamp: ${Date.now()},
                functions: {
                    hello: () => 'Hello from test module!',
                    add: (a, b) => a + b,
                    multiply: (a, b) => a * b
                },
                constants: {
                    PI: 3.14159,
                    E: 2.71828
                }
            };
        `;
        
        return moduleSystem.install(name, testCode, {
            version: '1.0.0',
            description: 'Módulo de prueba generado automáticamente'
        });
    }

    // Ejecutar suite de pruebas
    static async runTests() {
        console.group('🧪 ModuleSystem Test Suite');
        
        try {
            // 1. Instalar módulo de prueba
            ModuleHelper.createTestModule();
            console.log('✅ Test module installed');
            
            // 2. Cargar módulo de prueba
            const testModule = await moduleSystem.import('test-module');
            console.log('✅ Test module loaded');
            
            // 3. Verificar funcionalidad
            if (testModule.functions.hello() !== 'Hello from test module!') {
                throw new Error('Test module functionality failed');
            }
            console.log('✅ Test module functionality verified');
            
            // 4. Verificar cache
            const cachedModule = await moduleSystem.import('test-module');
            if (cachedModule !== testModule) {
                throw new Error('Cache system failed');
            }
            console.log('✅ Cache system working');
            
            // 5. Limpiar
            moduleSystem.uninstall('test-module');
            console.log('✅ Test module cleaned up');
            
            console.log('🎉 All tests passed!');
            
        } catch (error) {
            console.error('❌ Test failed:', error);
        }
        
        console.groupEnd();
    }

    // Generar documentación automática
    static generateDocs() {
        const modules = moduleSystem.listInstalledModules();
        const docs = {
            generated: new Date().toISOString(),
            modules: {}
        };
        
        modules.forEach(module => {
            if (!module.corrupted) {
                docs.modules[module.name] = {
                    version: module.version,
                    size: module.size,
                    dependencies: module.dependencies,
                    description: 'Auto-generated documentation'
                };
            }
        });
        
        return docs;
    }
}

// Exponer helper globalmente
window.ModuleHelper = ModuleHelper;
