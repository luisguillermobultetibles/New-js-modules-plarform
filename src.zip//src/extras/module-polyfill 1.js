// Polyfill avanzado para sistema de módulos ES6 con localStorage
class ModuleSystem {
    constructor(options = {}) {
        this.options = {
            debug: false,
            cacheEnabled: true,
            autoReload: true,
            timeout: 10000,
            ...options
        };
        
        this.modules = new Map();
        this.cache = new Map();
        this.importPromises = new Map();
        this.failedModules = new Set();
        this.dependencyGraph = new Map();
        this.eventHandlers = new Map();
        
        this.init();
    }

    init() {
        // Escuchar cambios en localStorage (para desarrollo)
        if (this.options.autoReload) {
            this._setupStorageListener();
        }
        
        // Exponer API global
        this._exposeGlobalAPI();
        
        this._log('🔧 Sistema de módulos inicializado', 'info');
    }

    // Polyfill principal para import()
    async import(moduleName, options = {}) {
        const importOptions = { ...this.options, ...options };
        
        // Validar nombre del módulo
        if (!this._isValidModuleName(moduleName)) {
            throw new Error(`Nombre de módulo inválido: "${moduleName}"`);
        }

        // Verificar si falló recientemente
        if (this.failedModules.has(moduleName) && !options.retry) {
            throw new Error(`Módulo "${moduleName}" marcado como fallido. Use retry: true para reintentar.`);
        }

        // Cache lookup
        if (importOptions.cacheEnabled && this.cache.has(moduleName)) {
            this._log(`📦 [CACHE] ${moduleName}`, 'debug');
            return this.cache.get(moduleName);
        }

        // Promesa existente
        if (this.importPromises.has(moduleName)) {
            this._log(`⏳ [REUSE] ${moduleName}`, 'debug');
            return this.importPromises.get(moduleName);
        }

        // Crear nueva promesa de importación
        const importPromise = this._loadModuleWithTimeout(moduleName, importOptions);
        this.importPromises.set(moduleName, importPromise);

        try {
            const moduleExports = await importPromise;
            
            // Cache exitoso
            if (importOptions.cacheEnabled) {
                this.cache.set(moduleName, moduleExports);
            }
            
            this.failedModules.delete(moduleName);
            this.importPromises.delete(moduleName);
            
            this._log(`✅ [LOADED] ${moduleName}`, 'success');
            this._emit('moduleLoaded', { moduleName, exports: moduleExports });
            
            return moduleExports;

        } catch (error) {
            this.failedModules.add(moduleName);
            this.importPromises.delete(moduleName);
            
            this._log(`❌ [FAILED] ${moduleName}: ${error.message}`, 'error');
            this._emit('moduleFailed', { moduleName, error });
            
            throw error;
        }
    }

    // Carga con timeout
    async _loadModuleWithTimeout(moduleName, options) {
        const timeoutPromise = new Promise((_, reject) => {
            setTimeout(() => reject(new Error(`Timeout loading module "${moduleName}"`)), options.timeout);
        });

        const loadPromise = this._loadModule(moduleName);
        
        return Promise.race([loadPromise, timeoutPromise]);
    }

    // Cargar módulo principal
    async _loadModule(moduleName) {
        // 1. Obtener datos del módulo
        const moduleData = this._getModuleData(moduleName);
        if (!moduleData) {
            throw new Error(`Módulo "${moduleName}" no encontrado. Ejecute el instalador primero.`);
        }

        // 2. Crear contexto del módulo
        const moduleContext = {
            exports: {},
            id: moduleName,
            filename: `localStorage://${moduleName}`,
            loaded: false,
            require: this._createRequireFunction(moduleName),
            children: []
        };

        // 3. Preparar entorno de ejecución
        const executionEnv = this._createExecutionEnvironment(moduleContext);

        try {
            // 4. Ejecutar código del módulo
            const exports = await this._executeModuleCode(moduleData.code, executionEnv);
            
            // 5. Procesar exports
            const finalExports = this._processExports(exports, moduleContext.exports);
            moduleContext.loaded = true;
            
            return finalExports;

        } catch (error) {
            throw new Error(`Error ejecutando módulo "${moduleName}": ${error.message}`);
        }
    }

    // Obtener datos del módulo desde localStorage
    _getModuleData(moduleName) {
        try {
            const stored = localStorage.getItem(`module_${moduleName}`);
            if (!stored) return null;

            const data = JSON.parse(stored);
            
            // Validar estructura
            if (!data.code || typeof data.code !== 'string') {
                throw new Error('Estructura de módulo inválida');
            }

            // Metadata adicional
            return {
                code: data.code,
                version: data.version || '1.0.0',
                timestamp: data.timestamp || Date.now(),
                dependencies: data.dependencies || [],
                checksum: data.checksum || this._generateChecksum(data.code)
            };

        } catch (error) {
            throw new Error(`Datos corruptos para módulo "${moduleName}": ${error.message}`);
        }
    }

    // Crear función require para dependencias
    _createRequireFunction(parentModule) {
        return (dependencyName) => {
            // Resolver dependencia
            const resolvedName = this._resolveDependency(dependencyName, parentModule);
            
            // Verificar cache
            if (this.cache.has(resolvedName)) {
                return this.cache.get(resolvedName);
            }

            // Cargar sincrónicamente (limitación)
            throw new Error(
                `Dependencia "${dependencyName}" no precargada para "${parentModule}". ` +
                `Use await import() en lugar de require().`
            );
        };
    }

    // Crear entorno de ejecución
    _createExecutionEnvironment(moduleContext) {
        return {
            // Objeto module
            module: moduleContext,
            
            // exports inicial
            exports: moduleContext.exports,
            
            // Función require
            require: moduleContext.require,
            
            // __filename y __dirname
            __filename: moduleContext.filename,
            __dirname: 'localStorage://',
            
            // Método de exportación mejorado
            __export: (exports) => {
                if (typeof exports === 'object' && exports !== null) {
                    Object.assign(moduleContext.exports, exports);
                }
                return moduleContext.exports;
            },
            
            // Para compatibilidad con CommonJS
            define: (deps, factory) => {
                if (typeof deps === 'function') {
                    factory = deps;
                    deps = [];
                }
                const exports = factory(moduleContext.require, moduleContext.exports, moduleContext);
                if (exports !== undefined) {
                    moduleContext.exports = exports;
                }
            }
        };
    }

    // Ejecutar código del módulo
    async _executeModuleCode(code, env) {
        try {
            // Crear función wrapper
            const wrappedCode = `
                return (function(module, exports, require, __filename, __dirname, __export, define) {
                    "use strict";
                    ${code}
                    return module.exports;
                });
            `;

            const factory = new Function(wrappedCode)();
            const result = factory(
                env.module, 
                env.exports, 
                env.require, 
                env.__filename, 
                env.__dirname,
                env.__export,
                env.define
            );

            // Manejar diferentes patrones de exportación
            return result !== undefined ? result : env.module.exports;

        } catch (error) {
            // Mejorar mensaje de error
            const enhancedError = new Error(`Execution error: ${error.message}`);
            enhancedError.originalError = error;
            enhancedError.stack = error.stack;
            throw enhancedError;
        }
    }

    // Procesar exports
    _processExports(executionResult, moduleExports) {
        // Si la ejecución devolvió algo, usarlo
        if (executionResult !== undefined && executionResult !== null) {
            return executionResult;
        }
        
        // Si no, usar module.exports
        if (Object.keys(moduleExports).length > 0) {
            return moduleExports;
        }
        
        // Módulo vacío
        return {};
    }

    // API PÚBLICA MEJORADA

    // Cargar múltiples módulos
    async importAll(moduleNames, options = {}) {
        const results = {};
        const promises = [];

        for (const moduleName of moduleNames) {
            promises.push(
                this.import(moduleName, options)
                    .then(exports => { results[moduleName] = exports; })
                    .catch(error => { results[moduleName] = error; })
            );
        }

        await Promise.allSettled(promises);
        return results;
    }

    // Preload modules
    async preload(moduleNames, options = {}) {
        this._log(`🔮 Preloading ${moduleNames.length} modules`, 'info');
        return this.importAll(moduleNames, { ...options, cacheEnabled: true });
    }

    // Verificar salud del módulo
    async healthCheck(moduleName) {
        try {
            const data = this._getModuleData(moduleName);
            if (!data) {
                return { healthy: false, error: 'Module not found' };
            }

            // Verificar checksum
            const currentChecksum = this._generateChecksum(data.code);
            if (data.checksum && data.checksum !== currentChecksum) {
                return { healthy: false, error: 'Checksum mismatch' };
            }

            // Verificar sintaxis
            new Function(data.code);

            return { 
                healthy: true, 
                version: data.version,
                size: new Blob([data.code]).size,
                timestamp: data.timestamp
            };

        } catch (error) {
            return { healthy: false, error: error.message };
        }
    }

    // Instalar módulo directamente
    install(moduleName, code, metadata = {}) {
        const moduleData = {
            code: code,
            version: metadata.version || '1.0.0',
            timestamp: Date.now(),
            dependencies: metadata.dependencies || [],
            checksum: this._generateChecksum(code),
            ...metadata
        };

        try {
            localStorage.setItem(`module_${moduleName}`, JSON.stringify(moduleData));
            this._log(`📥 Instalado: ${moduleName} v${moduleData.version}`, 'success');
            this._emit('moduleInstalled', { moduleName, metadata: moduleData });
            return true;
        } catch (error) {
            this._log(`❌ Error instalando ${moduleName}: ${error.message}`, 'error');
            return false;
        }
    }

    // Actualizar módulo
    async update(moduleName, newCode, newMetadata = {}) {
        const oldData = this._getModuleData(moduleName);
        if (!oldData) {
            throw new Error(`Módulo "${moduleName}" no encontrado para actualizar`);
        }

        // Limpiar cache
        this.cache.delete(moduleName);
        this.importPromises.delete(moduleName);
        this.failedModules.delete(moduleName);

        // Instalar nueva versión
        return this.install(moduleName, newCode, {
            ...oldData,
            ...newMetadata,
            previousVersion: oldData.version
        });
    }

    // Sistema de eventos
    on(event, handler) {
        if (!this.eventHandlers.has(event)) {
            this.eventHandlers.set(event, new Set());
        }
        this.eventHandlers.get(event).add(handler);
    }

    off(event, handler) {
        if (this.eventHandlers.has(event)) {
            this.eventHandlers.get(event).delete(handler);
        }
    }

    _emit(event, data) {
        if (this.eventHandlers.has(event)) {
            this.eventHandlers.get(event).forEach(handler => {
                try {
                    handler(data);
                } catch (error) {
                    console.error(`Error en event handler para ${event}:`, error);
                }
            });
        }
    }

    // UTILIDADES

    // Listar módulos con información detallada
    listInstalledModules() {
        const modules = [];
        
        for (let i = 0; i < localStorage.length; i++) {
            const key = localStorage.key(i);
            if (key.startsWith('module_')) {
                const name = key.replace('module_', '');
                try {
                    const data = JSON.parse(localStorage.getItem(key));
                    modules.push({
                        name,
                        version: data.version || '1.0.0',
                        timestamp: data.timestamp,
                        size: new Blob([data.code]).size,
                        dependencies: data.dependencies || [],
                        checksum: data.checksum,
                        installed: true
                    });
                } catch (e) {
                    modules.push({
                        name,
                        installed: true,
                        corrupted: true,
                        error: e.message
                    });
                }
            }
        }
        
        return modules.sort((a, b) => a.name.localeCompare(b.name));
    }

    // Obtener uso de almacenamiento
    getStorageUsage() {
        let totalSize = 0;
        let moduleCount = 0;
        
        for (let i = 0; i < localStorage.length; i++) {
            const key = localStorage.key(i);
            if (key.startsWith('module_')) {
                const value = localStorage.getItem(key);
                totalSize += key.length + (value ? value.length : 0);
                moduleCount++;
            }
        }
        
        const maxStorage = 5 * 1024 * 1024; // 5MB típico
        const usagePercent = (totalSize / maxStorage) * 100;
        
        return {
            moduleCount,
            totalSize,
            totalSizeKB: (totalSize / 1024).toFixed(2),
            totalSizeMB: (totalSize / (1024 * 1024)).toFixed(2),
            usagePercent: usagePercent.toFixed(1),
            available: maxStorage - totalSize
        };
    }

    // Limpiar cache específico
    clearCache(moduleName = null) {
        if (moduleName) {
            this.cache.delete(moduleName);
            this._log(`🗑️ Cache limpiado: ${moduleName}`, 'info');
        } else {
            this.cache.clear();
            this._log('🗑️ Cache completo limpiado', 'info');
        }
        this._emit('cacheCleared', { moduleName });
    }

    // Eliminar módulo
    uninstall(moduleName) {
        localStorage.removeItem(`module_${moduleName}`);
        this.cache.delete(moduleName);
        this.importPromises.delete(moduleName);
        this.failedModules.delete(moduleName);
        
        this._log(`🗑️ Desinstalado: ${moduleName}`, 'info');
        this._emit('moduleUninstalled', { moduleName });
    }

    // MÉTODOS PRIVADOS

    _isValidModuleName(name) {
        return typeof name === 'string' && 
               name.length > 0 && 
               /^[a-zA-Z0-9_-]+$/.test(name);
    }

    _resolveDependency(dep, parent) {
        // Resolución simple - podría extenderse para paths relativos
        return dep;
    }

    _generateChecksum(code) {
        let hash = 0;
        for (let i = 0; i < code.length; i++) {
            const char = code.charCodeAt(i);
            hash = ((hash << 5) - hash) + char;
            hash = hash & hash; // Convert to 32bit integer
        }
        return hash.toString(36);
    }

    _setupStorageListener() {
        window.addEventListener('storage', (e) => {
            if (e.key && e.key.startsWith('module_')) {
                const moduleName = e.key.replace('module_', '');
                this._log(`🔄 Storage cambiado: ${moduleName}`, 'debug');
                
                // Limpiar cache del módulo afectado
                this.cache.delete(moduleName);
                this.importPromises.delete(moduleName);
                
                this._emit('moduleUpdated', { moduleName });
            }
        });
    }

    _exposeGlobalAPI() {
        // Polyfill para import()
        window.import = (moduleName) => this.import(moduleName);
        
        // API global para debugging
        window.moduleSystem = this;
        
        // Atajo común
        window.require = (moduleName) => {
            console.warn('⚠️ Use "await import()" instead of "require()" for async modules');
            if (this.cache.has(moduleName)) {
                return this.cache.get(moduleName);
            }
            throw new Error(`Module "${moduleName}" not loaded. Use "await import('${moduleName}')"`);
        };
    }

    _log(message, level = 'info') {
        if (!this.options.debug && level === 'debug') return;
        
        const styles = {
            info: 'color: blue;',
            success: 'color: green; font-weight: bold;',
            error: 'color: red; font-weight: bold;',
            warning: 'color: orange;',
            debug: 'color: gray; font-style: italic;'
        };
        
        console.log(`%c[ModuleSystem] ${message}`, styles[level] || '');
    }
}

// Inicialización automática
const moduleSystem = new ModuleSystem({
    debug: true,  // Cambiar a false en producción
    cacheEnabled: true,
    autoReload: true,
    timeout: 15000
});

// Exportar para módulos (si es necesario)
if (typeof module !== 'undefined' && module.exports) {
    module.exports = moduleSystem;
}
