// Polyfill para sistema de módulos ES6 con localStorage
class ModuleSystem {
    constructor() {
        this.modules = new Map();
        this.cache = new Map();
        this.importPromises = new Map();
        this.basePath = './modules/';
        
        // Exponer globalmente para debugging
        window.ModuleSystem = this;
    }

    // Polyfill para import()
    async import(moduleName) {
        // Si ya está en cache, devolver inmediatamente
        if (this.cache.has(moduleName)) {
            return this.cache.get(moduleName);
        }

        // Si ya hay una promesa de import en curso, reutilizarla
        if (this.importPromises.has(moduleName)) {
            return this.importPromises.get(moduleName);
        }

        // Crear nueva promesa de import
        const importPromise = this._loadModule(moduleName);
        this.importPromises.set(moduleName, importPromise);

        try {
            const moduleExports = await importPromise;
            this.cache.set(moduleName, moduleExports);
            this.importPromises.delete(moduleName);
            return moduleExports;
        } catch (error) {
            this.importPromises.delete(moduleName);
            throw error;
        }
    }

    // Cargar módulo desde localStorage
    async _loadModule(moduleName) {
        try {
            // 1. Buscar en localStorage
            const storedModule = localStorage.getItem(`module_${moduleName}`);
            if (!storedModule) {
                throw new Error(`Módulo '${moduleName}' no encontrado en localStorage. Ejecuta el instalador primero.`);
            }

            const moduleData = JSON.parse(storedModule);
            
            // 2. Crear contexto de módulo
            const module = {
                exports: {},
                loaded: false,
                id: moduleName
            };

            // 3. Función require para dependencias internas
            const require = (dep) => {
                if (this.cache.has(dep)) {
                    return this.cache.get(dep);
                }
                throw new Error(`Dependencia '${dep}' no cargada para módulo '${moduleName}'`);
            };

            // 4. Función para simular export
            const exportFn = (exports) => {
                if (typeof exports === 'object' && exports !== null) {
                    Object.assign(module.exports, exports);
                }
                return exports;
            };

            // 5. Ejecutar el código del módulo
            const factoryCode = `
                return (function(module, exports, require, __export) {
                    ${moduleData.code}
                    return module.exports;
                });
            `;

            const factory = new Function(factoryCode)();
            const result = factory(module, module.exports, require, exportFn);

            // 6. Manejar diferentes estilos de exportación
            if (result !== undefined) {
                module.exports = result;
            }

            module.loaded = true;
            
            console.log(`✅ Módulo '${moduleName}' cargado correctamente`);
            return module.exports;

        } catch (error) {
            console.error(`❌ Error cargando módulo '${moduleName}':`, error);
            throw new Error(`Failed to load module '${moduleName}': ${error.message}`);
        }
    }

    // Cargar múltiples módulos en paralelo
    async importAll(moduleNames) {
        const imports = moduleNames.map(name => this.import(name));
        const results = await Promise.allSettled(imports);
        
        const modules = {};
        results.forEach((result, index) => {
            const moduleName = moduleNames[index];
            if (result.status === 'fulfilled') {
                modules[moduleName] = result.value;
            } else {
                console.warn(`⚠️ No se pudo cargar '${moduleName}':`, result.reason);
                modules[moduleName] = null;
            }
        });
        
        return modules;
    }

    // Verificar si un módulo está instalado
    isInstalled(moduleName) {
        return localStorage.getItem(`module_${moduleName}`) !== null;
    }

    // Listar todos los módulos instalados
    listInstalledModules() {
        const modules = [];
        for (let i = 0; i < localStorage.length; i++) {
            const key = localStorage.key(i);
            if (key.startsWith('module_')) {
                const name = key.replace('module_', '');
                try {
                    const data = JSON.parse(localStorage.getItem(key));
                    modules.push({
                        name: name,
                        version: data.version || '1.0.0',
                        timestamp: data.timestamp,
                        size: new Blob([data.code]).size
                    });
                } catch (e) {
                    console.warn(`Módulo corrupto: ${name}`);
                }
            }
        }
        return modules;
    }

    // Obtener información de un módulo específico
    getModuleInfo(moduleName) {
        const stored = localStorage.getItem(`module_${moduleName}`);
        if (!stored) return null;
        
        try {
            const data = JSON.parse(stored);
            return {
                name: moduleName,
                version: data.version || '1.0.0',
                timestamp: data.timestamp,
                codeSize: new Blob([data.code]).size,
                installed: true
            };
        } catch (e) {
            return null;
        }
    }

    // Limpiar cache de módulos
    clearCache() {
        this.cache.clear();
        this.importPromises.clear();
        console.log('🔄 Cache de módulos limpiado');
    }

    // Eliminar módulo específico
    removeModule(moduleName) {
        localStorage.removeItem(`module_${moduleName}`);
        this.cache.delete(moduleName);
        this.importPromises.delete(moduleName);
    }

    // Obtener uso de almacenamiento
    getStorageUsage() {
        let totalSize = 0;
        let moduleCount = 0;
        
        for (let i = 0; i < localStorage.length; i++) {
            const key = localStorage.key(i);
            if (key.startsWith('module_')) {
                const value = localStorage.getItem(key);
                totalSize += key.length + value.length;
                moduleCount++;
            }
        }
        
        return {
            moduleCount,
            totalSize,
            totalSizeKB: (totalSize / 1024).toFixed(2)
        };
    }
}

// Crear instancia global
const moduleSystem = new ModuleSystem();

// Polyfill para window.import (similar a dynamic import)
window.import = function(moduleName) {
    return moduleSystem.import(moduleName);
};

// Exponer el sistema de módulos globalmente
window.moduleSystem = moduleSystem;
