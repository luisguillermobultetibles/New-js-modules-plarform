// Sistema de módulos unificado - Local + Remoto
class UnifiedModuleSystem {
    constructor(config = {}) {
        this.config = {
            // Configuración base
            debug: false,
            cacheEnabled: true,
            timeout: 10000,
            
            // Estrategia de carga
            strategy: 'hybrid', // 'local-only', 'remote-only', 'hybrid'
            fallback: true,
            
            // Proveedores remotos
            providers: [
                {
                    name: 'local-storage',
                    type: 'local',
                    priority: 1,
                    enabled: true
                },
                {
                    name: 'webrtc-swarm',
                    type: 'webrtc', 
                    priority: 2,
                    enabled: true,
                    signaling: ['wss://signaling.example.com']
                },
                {
                    name: 'http-cdn',
                    type: 'http',
                    priority: 3,
                    enabled: true,
                    endpoints: ['https://cdn.modules.com/v1']
                },
                {
                    name: 'ipfs-network',
                    type: 'ipfs',
                    priority: 4,
                    enabled: false,
                    gateway: 'https://ipfs.io/ipfs'
                }
            ],
            
            ...config
        };
        
        this.providers = new Map();
        this.cache = new Map();
        this.importPromises = new Map();
        this.moduleRegistry = new Map();
        this.peerConnections = new Map();
        
        this.init();
    }

    async init() {
        // Inicializar proveedores
        await this._initializeProviders();
        
        // Conectar a redes
        await this._connectToNetworks();
        
        // Exponer API global
        this._exposeGlobalAPI();
        
        this._log('🔧 Sistema unificado inicializado', 'success');
    }

    // INTERFACE ESTÁNDAR - Igual para todos los entornos
    async import(moduleSpecifier, options = {}) {
        // Resolver el specifier a URL/identificador
        const resolved = await this._resolveModule(moduleSpecifier);
        
        // Verificar cache primero
        if (this.cache.has(resolved.id)) {
            return this.cache.get(resolved.id);
        }

        // Cargar módulo usando estrategia configurada
        const module = await this._loadWithStrategy(resolved, options);
        
        // Cachear resultado
        this.cache.set(resolved.id, module);
        
        return module;
    }
}

  
