// Resolvedor de módulos unificado
class UnifiedModuleResolver {
    constructor() {
        this.schemes = new Map();
        this._registerDefaultSchemes();
    }

    _registerDefaultSchemes() {
        // Esquema local (localStorage)
        this.registerScheme('local:', (specifier) => {
            const moduleName = specifier.replace('local:', '');
            return {
                id: `local:${moduleName}`,
                type: 'local',
                name: moduleName,
                providers: ['local-storage']
            };
        });

        // Esquema P2P (WebRTC)
        this.registerScheme('p2p:', (specifier) => {
            const parts = specifier.replace('p2p:', '').split('/');
            return {
                id: `p2p:${specifier}`,
                type: 'webrtc',
                peer: parts[0],
                module: parts[1],
                providers: ['webrtc-swarm']
            };
        });

        // Esquema HTTP estándar
        this.registerScheme('http:', (specifier) => ({
            id: specifier,
            type: 'http',
            url: specifier,
            providers: ['http-cdn']
        }));

        // Esquema CDN
        this.registerScheme('cdn:', (specifier) => ({
            id: `cdn:${specifier}`,
            type: 'http',
            url: `https://cdn.modules.com/v1/${specifier}.js`,
            providers: ['http-cdn']
        }));

        // Esquema IPFS
        this.registerScheme('ipfs:', (specifier) => ({
            id: `ipfs:${specifier}`,
            type: 'ipfs',
            cid: specifier.replace('ipfs:', ''),
            providers: ['ipfs-network']
        }));

        // Sin esquema (búsqueda inteligente)
        this.registerScheme('', (specifier) => this._resolveBareSpecifier(specifier));
    }

    async resolve(specifier, referrer = null) {
        // Detectar esquema
        const scheme = this._detectScheme(specifier);
        
        if (this.schemes.has(scheme)) {
            return this.schemes.get(scheme)(specifier, referrer);
        }
        
        // Resolución por defecto
        return this._resolveBareSpecifier(specifier, referrer);
    }

    registerScheme(scheme, resolver) {
        this.schemes.set(scheme, resolver);
    }

    _resolveBareSpecifier(specifier, referrer) {
        // Estrategia de resolución inteligente
        return {
            id: specifier,
            type: 'hybrid',
            name: specifier,
            providers: ['local-storage', 'webrtc-swarm', 'http-cdn'],
            searchOrder: ['local', 'p2p', 'http']
        };
    }
}
