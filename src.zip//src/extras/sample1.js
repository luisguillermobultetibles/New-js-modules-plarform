// USO TRANSPARENTE - Mismo código para todos los entornos

// 1. Módulo local
const math = await import('local:math-utils');
const dom = await import('local:dom-manager');

// 2. Módulo P2P  
const p2pModule = await import('p2p:peer-id/module-name');

// 3. Módulo HTTP
const httpModule = await import('cdn:popular-library');

// 4. Resolución automática (inteligente)
const utils = await import('my-utils'); // Busca en local → P2P → HTTP

// 5. Publicación
await universalModuleSystem.publish('my-module', `
    export function hello() { return "Hello World!"; }
    export const version = '1.0.0';
`, {
    version: '1.0.0',
    description: 'My awesome module',
    dependencies: ['local:math-utils']
});

// 6. Sincronización
await universalModuleSystem.syncModule('shared-module');
