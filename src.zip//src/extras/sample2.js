// Uso avanzado del polyfill en tu aplicación

// 1. Configuración inicial
async function initializeApp() {
    try {
        // Precargar módulos esenciales
        const essentialModules = await moduleSystem.preload([
            'dom-manager',
            'storage-pro', 
            'math-utils'
        ]);
        
        // Verificar salud
        const health = await moduleSystem.healthCheck('dom-manager');
        if (!health.healthy) {
            throw new Error('DOM manager module corrupted');
        }
        
        // Configurar event listeners
        moduleSystem.on('moduleLoaded', ({ moduleName }) => {
            console.log(`🎉 ${moduleName} ready to use!`);
        });
        
        moduleSystem.on('moduleFailed', ({ moduleName, error }) => {
            console.error(`💥 ${moduleName} failed:`, error);
            showErrorToUser(`Module ${moduleName} failed to load`);
        });
        
        return essentialModules;
        
    } catch (error) {
        console.error('App initialization failed:', error);
        fallbackToCDN();
    }
}

// 2. Uso con error boundaries
async function loadModuleWithFallback(moduleName, fallbackUrl) {
    try {
        return await moduleSystem.import(moduleName);
    } catch (error) {
        console.warn(`Local module failed, falling back to CDN: ${moduleName}`);
        return await loadFromCDN(fallbackUrl);
    }
}

// 3. Actualización en caliente
async function updateModule(moduleName, newVersion) {
    try {
        const newCode = await fetchModuleFromServer(moduleName, newVersion);
        await moduleSystem.update(moduleName, newCode, { version: newVersion });
        
        // Recargar módulo en la app
        await reloadModuleInApp(moduleName);
        
    } catch (error) {
        console.error('Failed to update module:', error);
    }
}

// 4. Diagnóstico automático
async function autoDiagnose() {
    if (moduleSystem.getStorageUsage().usagePercent > 80) {
        console.warn('📛 Storage almost full, clearing cache');
        moduleSystem.clearCache();
    }
    
    const report = await ModuleHelper.diagnose();
    if (report.results.healthChecks.some(check => !check.healthy)) {
        console.error('🚨 Corrupted modules detected');
        await repairCorruptedModules();
    }
}
