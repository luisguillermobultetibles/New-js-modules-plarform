// En cualquier parte de tu aplicación puedes usar:

// Importación simple
const math = await import('math-utils');
console.log(math.PI); // 3.14159265359

// Múltiples importaciones
const [dom, storage] = await Promise.all([
    import('dom-manager'),
    import('storage-pro')
]);

// Con manejo de errores
try {
    const http = await import('http-client');
    const data = await http.get('https://api.example.com/data');
} catch (error) {
    console.error('Módulo no disponible:', error);
}

// Verificar disponibilidad
if (moduleSystem.isInstalled('validation-suite')) {
    const validator = await import('validation-suite');
    // Usar el módulo...
}
