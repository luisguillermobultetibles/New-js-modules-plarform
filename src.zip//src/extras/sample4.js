// Así como en ES6 nativo
const modulo = await import('nombre-modulo');
