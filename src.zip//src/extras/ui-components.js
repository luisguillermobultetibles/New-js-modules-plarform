// Ejemplo 2: Módulo de UI components
// ui-components.js
export class Modal {
    constructor(options = {}) {
        this.options = { ...Modal.defaultOptions, ...options };
        this.element = this.createModal();
    }
    
    static defaultOptions = {
        title: 'Modal',
        content: '',
        closeButton: true,
        overlay: true
    };
    
    createModal() {
        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.innerHTML = `
            ${this.options.overlay ? '<div class="modal-overlay"></div>' : ''}
            <div class="modal-content">
                ${this.options.closeButton ? '<button class="modal-close">&times;</button>' : ''}
                <h2 class="modal-title">${this.options.title}</h2>
                <div class="modal-body">${this.options.content}</div>
            </div>
        `;
        
        this.setupEvents(modal);
        return modal;
    }
    
    setupEvents(modal) {
        const closeBtn = modal.querySelector('.modal-close');
        const overlay = modal.querySelector('.modal-overlay');
        
        if (closeBtn) {
            closeBtn.addEventListener('click', () => this.close());
        }
        
        if (overlay) {
            overlay.addEventListener('click', () => this.close());
        }
    }
    
    open() {
        document.body.appendChild(this.element);
        document.body.style.overflow = 'hidden';
    }
    
    close() {
        this.element.remove();
        document.body.style.overflow = '';
    }
}

export function createNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.remove();
    }, 3000);
    
    return notification;
}

// CSS asociado (podría estar en otro módulo)
export const styles = `
    .modal { position: fixed; top: 0; left: 0; width: 100%; height: 100%; z-index: 1000; }
    .modal-overlay { position: absolute; width: 100%; height: 100%; background: rgba(0,0,0,0.5); }
    .modal-content { position: relative; background: white; margin: 50px auto; padding: 20px; max-width: 500px; border-radius: 8px; }
    .modal-close { position: absolute; top: 10px; right: 10px; background: none; border: none; font-size: 20px; cursor: pointer; }
    .notification { position: fixed; top: 20px; right: 20px; padding: 15px 20px; border-radius: 4px; color: white; z-index: 1001; }
    .notification-info { background: #2196F3; }
    .notification-success { background: #4CAF50; }
    .notification-error { background: #f44336; }
`;
