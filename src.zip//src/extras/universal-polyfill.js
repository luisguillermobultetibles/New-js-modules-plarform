// Implementación final del sistema unificado
class UniversalModuleSystem extends UnifiedModuleSystem {
    async _initializeProviders() {
        for (const providerConfig of this.config.providers) {
            if (!providerConfig.enabled) continue;
            
            let provider;
            switch (providerConfig.type) {
                case 'local':
                    provider = new LocalStorageProvider(providerConfig.name, providerConfig);
                    break;
                case 'webrtc':
                    provider = new WebRTCProvider(providerConfig.name, providerConfig);
                    break;
                case 'http':
                    provider = new HTTPProvider(providerConfig.name, providerConfig);
                    break;
                case 'ipfs':
                    provider = new IPFSProvider(providerConfig.name, providerConfig);
                    break;
                default:
                    console.warn(`Unknown provider type: ${providerConfig.type}`);
                    continue;
            }
            
            try {
                await provider.init();
                this.providers.set(providerConfig.name, provider);
                this._log(`✅ Provider initialized: ${providerConfig.name}`);
            } catch (error) {
                this._log(`❌ Failed to initialize ${providerConfig.name}: ${error.message}`, 'error');
            }
        }
    }

    async _loadWithStrategy(resolvedId, options) {
        const strategy = new HybridLoadStrategy(this.providers, this.config);
        const moduleData = await strategy.loadModule(resolvedId, options);
        
        // Ejecutar el módulo
        return this._executeModule(moduleData.code, resolvedId);
    }

    _executeModule(code, moduleId) {
        const module = { exports: {} };
        const require = (dep) => {
            throw new Error(`Dynamic require not supported. Use import() for: ${dep}`);
        };

        const factory = new Function('module', 'exports', 'require', code);
        factory(module, module.exports, require);
        
        return module.exports;
    }

    // MÉTODOS DE GESTIÓN

    async publish(moduleName, code, metadata = {}) {
        const resolvedId = await this.resolver.resolve(moduleName);
        
        // Publicar en todos los proveedores habilitados
        const results = [];
        for (const provider of this.providers.values()) {
            if (provider.storeModule) {
                try {
                    const result = await provider.storeModule(resolvedId, code, metadata);
                    results.push({ provider: provider.name, success: true, result });
                } catch (error) {
                    results.push({ provider: provider.name, success: false, error: error.message });
                }
            }
        }
        
        return results;
    }

    async syncModule(moduleName) {
        const resolvedId = await this.resolver.resolve(moduleName);
        const strategy = new HybridLoadStrategy(this.providers, this.config);
        
        // Forzar sincronización desde la mejor fuente
        const moduleData = await strategy.loadModule(resolvedId, { forceSync: true });
        
        // Replicar en todos los proveedores
        await this._replicateToAll(resolvedId, moduleData);
        
        return moduleData;
    }

    getNetworkStatus() {
        const status = {
            providers: {},
            moduleCount: this.moduleRegistry.size,
            cacheSize: this.cache.size
        };
        
        for (const [name, provider] of this.providers) {
            status.providers[name] = provider.getHealth();
        }
        
        return status;
    }
}

// Inicialización global
const universalModuleSystem = new UniversalModuleSystem({
    strategy: 'hybrid',
    debug: true,
    providers: [
        {
            name: 'local-storage',
            type: 'local',
            priority: 1,
            enabled: true
        },
        {
            name: 'webrtc-swarm', 
            type: 'webrtc',
            priority: 2,
            enabled: true,
            signaling: ['wss://signaling1.example.com', 'wss://signaling2.example.com']
        },
        {
            name: 'http-cdn',
            type: 'http', 
            priority: 3,
            enabled: true,
            endpoints: [
                'https://cdn.modules.com/v1',
                'https://backup.modules.com/v1'
            ]
        }
    ]
});

// Polyfill para import() global
window.import = (moduleSpecifier) => universalModuleSystem.import(moduleSpecifier);
