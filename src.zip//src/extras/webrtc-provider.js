// Proveedor WebRTC P2P
class WebRTCProvider extends ModuleProvider {
    async init() {
        this.peers = new Map();
        this.moduleCache = new Map();
        this.connection = await this._connectToSignaling();
        return true;
    }

    async _connectToSignaling() {
        // Conectar a servidores de signaling
        const ws = new WebSocket(this.config.signaling[0]);
        
        return new Promise((resolve, reject) => {
            ws.onopen = () => {
                this._log('Connected to signaling server');
                resolve(ws);
            };
            
            ws.onerror = reject;
        });
    }

    async hasModule(moduleId) {
        // Buscar en peers conectados
        for (const peer of this.peers.values()) {
            if (peer.modules && peer.modules.has(moduleId.name)) {
                return true;
            }
        }
        return false;
    }

    async loadModule(moduleId) {
        // Buscar módulo en la red P2P
        const request = {
            type: 'module-request',
            module: moduleId.name,
            requestId: Math.random().toString(36).substr(2, 9)
        };

        // Enviar request a todos los peers
        this._broadcast(request);

        // Esperar respuesta con timeout
        return new Promise((resolve, reject) => {
            const timeout = setTimeout(() => {
                reject(new Error(`Timeout waiting for module: ${moduleId.name}`));
            }, this.config.timeout || 10000);

            const handler = (response) => {
                if (response.requestId === request.requestId && response.module) {
                    clearTimeout(timeout);
                    this.connection.removeEventListener('message', handler);
                    resolve({
                        code: response.module.code,
                        metadata: {
                            version: response.module.version,
                            source: `p2p:${response.peerId}`,
                            peer: response.peerId
                        }
                    });
                }
            };

            this.connection.addEventListener('message', handler);
        });
    }

    async storeModule(moduleId, code, metadata) {
        // Anunciar módulo a la red P2P
        const announcement = {
            type: 'module-announce',
            module: {
                name: moduleId.name,
                code: code,
                version: metadata.version,
                timestamp: Date.now()
            }
        };

        this._broadcast(announcement);
        return true;
    }

    _broadcast(message) {
        for (const peer of this.peers.values()) {
            peer.send(JSON.stringify(message));
        }
    }
}

